package com.example.demo15;

public class DisplayCourseInfo {
    Course course;

}
